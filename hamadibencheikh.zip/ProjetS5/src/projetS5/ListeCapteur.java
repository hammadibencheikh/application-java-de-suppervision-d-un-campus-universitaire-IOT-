package projetS5;

import java.util.ArrayList;

public class ListeCapteur {
	ArrayList<Capteur> listeCapteur;
	
	public ListeCapteur() {
		listeCapteur = new ArrayList<>();
	}
	
	public ArrayList<Capteur> getTab(){
		return listeCapteur;
	}
	
	public int getNbCapteur() {
		return listeCapteur.size();
	}
	
	public Capteur getCapteur(int indice) {
		return listeCapteur.get(indice);
	}

	public void add(Capteur capteur) {
		listeCapteur.add(capteur);
	}
	public void vider () {
		listeCapteur.clear();
	}
}
