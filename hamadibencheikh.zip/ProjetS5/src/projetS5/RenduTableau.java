package projetS5;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

public class RenduTableau extends DefaultTableCellRenderer {
	private static final Color ROUGE = new Color(240,0,0);
	private static final Color BLANC = new Color(255,255,255);
	private TableColumnModel modeleColonne;
		
	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column){
		super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
		
		if(column == 0 || column == 3 || column == 6 || column == 7 || column == 8) {
			setText(String.valueOf(value));
			setHorizontalAlignment(JLabel.LEFT);
		} else 
			setText(String.valueOf(value));
		
		if(((Double)table.getValueAt(row, 6)<(Double)table.getValueAt(row, 7)) || ((Double)table.getValueAt(row, 6)>(Double)table.getValueAt(row, 8))) { 
			modeleColonne = table.getColumnModel();
			for(int i=0; i<table.getColumnCount();i++) {
				modeleColonne.getColumn(i).setCellRenderer(new RenduTableau());
				this.setBackground(ROUGE);		
			}
		}
		else
			this.setBackground(BLANC);
		
		return this;
	}
	
	
}
