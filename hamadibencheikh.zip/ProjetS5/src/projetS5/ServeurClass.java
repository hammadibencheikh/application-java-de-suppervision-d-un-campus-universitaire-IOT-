package projetS5;



import java.net.* ;
import java.io.* ;
public class ServeurClass implements Runnable {
	int port ;
	public ServeurClass(int p) {
	 		port=p ;
	 	}


	public void run() {
		try {
		ServerSocket ss=new ServerSocket(port);
		Socket s=ss.accept();
		Serveur ser=new Serveur(ss,s) ;
		Thread t=new Thread(ser) ;
		t.start();
		}catch(IOException e) {
			
		}
		
		
	}
	public static void main(String args[]) {
		new ServeurClass(601).run() ;
	}
}