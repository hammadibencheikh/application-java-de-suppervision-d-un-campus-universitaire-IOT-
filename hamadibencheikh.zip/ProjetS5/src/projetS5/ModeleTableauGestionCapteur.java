package projetS5;

import javax.swing.table.AbstractTableModel;

@SuppressWarnings("serial")
public class ModeleTableauGestionCapteur extends AbstractTableModel {
	private String[] columnNames = {
			"Unit�",
			"Seuil minimum",
			"Seuil maximum" };
	private String unite;
	
	private Double seuilMin;
	private Double seuilMax;
	
	public ModeleTableauGestionCapteur(String s1 , float f1 , float f2) {
		
		seuilMin =(double) f1;
		seuilMax = (double)f2;
		if (s1.equals("ELECTRICITE"))
			 unite="V" ;
		if(s1.equals("TEMPERATURE"))
			unite="C" ;
		if(s1.equals("EAU"))
			unite="L" ;
		if(s1.equals("AIR_COMPRIME"))
			unite= "M�" ;
	
	}
	
	@Override
	public int getColumnCount() {
		return 3;
	}

	@Override
	public int getRowCount() {
		return 1;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		if(rowIndex==0) {
			switch (columnIndex) {
			case 0 : return unite;
			case 1 :return seuilMin;
			case 2 : return seuilMax;
			default : return null;
			}
		}
		return getColumnName(columnIndex); 
	}
	
	public String getUnite() {
		return unite ;
		}
	
	
	public String getColumnName(int columnIndex) {
		return this.columnNames[columnIndex];
	}
}