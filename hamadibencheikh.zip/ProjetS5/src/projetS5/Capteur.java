package projetS5;

public class Capteur {
	public int numTab;
	public String nom;
	public String bat;
	public int etage;
	public String loc;
	public Type type;
	public Double valeur;
	public Double seuilMin;
	public Double seuilMax;
	
	public Capteur(int numTab, String nom,String bat, int etage, String loc, Type type, Double valeur, Double seuilMin, Double seuilMax) {
		this.numTab = numTab;
		this.nom = nom;
		this.bat = bat;
		this.etage = etage;
		this.loc = loc;
		this.type = type;
		this.valeur = valeur;
		this.seuilMin = seuilMin;
		this.seuilMax = seuilMax;
	}
	
	public Double getSeuilMin() {
		return seuilMin;
	}
	
	public Double getSeuilMax() {
		return seuilMax;
	}
	
	public int getNumTab() {
		return numTab;
	}

	public String getNom() {
		return nom;
	}

	public String getBat() {
		return bat;
	}

	public int getEtage() {
		return etage;
	}

	public String getLoc() {
		return loc;
	}

	public Type getType() {
		return type;
	}

	public Double getValeur() {
		return valeur;
	}
	
}