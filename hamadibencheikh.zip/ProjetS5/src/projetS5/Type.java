package projetS5;

public enum Type {
	EAU, ELECTRICITE, AIR_COMPRIMEE, TEMPERATURE;
}
