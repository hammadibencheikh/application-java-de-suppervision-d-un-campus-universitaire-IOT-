package projetS5;
//import java.awt.List;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.* ;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;
		
		public class Serveur implements Runnable {
	
		     int SocketServerPORT  ;
		    ServerSocket serverSocket;
		    Socket s =null ;
		    ServerSocket ser ;
		    public Serveur(ServerSocket ser,Socket s){
		    	this.ser=ser ;
		           this.s=s ;

		    }



		    
		   
		    @SuppressWarnings("deprecation")
			public void run() {
		    
		    	ResultSet rslt;
		    	ResultSet rslt1 ;
		    	ResultSet rslt2 ;
		   
		        DataInputStream dataInputStream = null;
		 

		        try {
		        	s=ser.accept() ;
		      //      serverSocket = new ServerSocket(SocketServerPORT);
		            java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost/saklibouhlel_walosik_atmaniou?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","") ;
		        	System.out.println("Connection success") ;
		        	java.sql.Statement stc=con.createStatement() ;
 		        	   stc.executeUpdate("Delete from valeur") ;
				        stc.executeUpdate("Delete from capteur") ;
				        System.out.println("Database Cleared") ;
					java.sql.Statement st =con.createStatement();
					java.sql.Statement st1 =con.createStatement();
					java.sql.Statement st2 =con.createStatement();
					 dataInputStream = new DataInputStream(
		                        s.getInputStream());
					while (true) {
						//s=ser.accept() ;
		            
		    
		                String request ;

		    
		                try {
		                	//s=ser.accept();
		                	if(dataInputStream.available()!=0) {
		                request = dataInputStream.readLine();
		               System.out.println(request) ;  
		               if(request.startsWith("Connexion")) {
		            	   ;
		            	   rslt=st.executeQuery("select * from capteur where nomcapteur='"+request.substring(request.indexOf(' ')+1,request.indexOf(' ')+9)+"'") ;
		            	 rslt1=st1.executeQuery("select * from batiment where nombatiment='"+request.substring(request.indexOf(':')+1,request.indexOf(':')+3)+"'") ;
		            	 rslt2=st2.executeQuery("select * from etage where nombatiment='"+request.substring(request.indexOf(':')+1,request.indexOf(':')+3)+"' and numetage='"+request.substring(request.indexOf(':')+4,request.indexOf(':')+5)+"'") ;
		            	rslt.beforeFirst(); 
		            	rslt1.beforeFirst();
		            	rslt2.beforeFirst();
		            	   if(rslt.next()==false) {
		            		   
				               st.executeUpdate("INSERT INTO capteur VALUES('"+request.substring(request.indexOf(' ')+1,request.indexOf(' ')+9)+"',"+request.substring(request.indexOf(':')+4,request.indexOf(':')+5)+",'"+request.substring(request.indexOf(':')+1,request.indexOf(':')+3)+"','"+request.substring(request.indexOf(' ')+10,request.indexOf(':'))+"','"+request.substring(request.indexOf(':')+6,request.length())+"','"+"on"+"',0,0)") ;
				               }
		            	if(rslt1.next()==false) {
		            	  st.executeUpdate("INSERT INTO batiment VALUES('"+request.substring(request.indexOf(':')+1,request.indexOf(':')+3) +"')") ;
		            	  }
		            	 if(rslt2.next()==false) {
		            		 st.executeUpdate("INSERT INTO ETAGE VALUES ('"+request.substring(request.indexOf(':')+1,request.indexOf(':')+3)+"','"+request.substring(request.indexOf(':')+4,request.indexOf(':')+5)+"')") ;
		            	 }
		            	
		               }
		               if(request.startsWith("Donnee")) {
		            	   
		            	   
		            	   System.out.println(request) ;
		            	  
		            	   Calendar c=Calendar.getInstance() ;
		            	 
		            	   java.sql.Timestamp timestamp = new java.sql.Timestamp(c.getTimeInMillis());
		            	   System.out.println("insertion") ;
		            	 //  s=ser.accept() ;
		            	  st.executeUpdate("INSERT INTO valeur VALUES ('"+request.substring(request.indexOf(' ')+1,request.indexOf(' ')+9)+"',"+request.substring(request.indexOf(' ')+10,request.length())+",'"+timestamp+"')") ;
		            	  s=ser.accept() ;
		               }
		               if(request.startsWith("Deconnexion")) {
		            	  // s=ser.accept() ;
		            	   System.out.println(request) ;
		            	   st.executeUpdate("UPDATE capteur SET etat='off' where nomcapteur ='"+request.substring(request.indexOf(' ')+1,request.length())+"'") ;
		               }
		         
		                	}
		                }catch(IOException e) {
		                	System.out.println("Error") ;
		                }
		                dataInputStream = new DataInputStream(
		                        s.getInputStream());
		             //   s=ser.accept() ;
		            }
		        } catch (IOException e) {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		            final String errMsg = e.toString();

		        } catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} finally {
					
					
		            if (s != null) {
		                try {
		                    s.close();
		                } catch (IOException e) {
		                    // TODO Auto-generated catch block
		                    e.printStackTrace();
		                }
		            }

		            if (dataInputStream != null) {
		                try {
		                    dataInputStream.close();
		                } catch (IOException e) {
		                    // TODO Auto-generated catch block
		                    e.printStackTrace();
		                }
		            }

		        
		        }
		    }
		    public static void main (String args[]) {
		 //   	Serveur s=new Serveur(6150);
		    //	s.run();
		    	
		    }
		}