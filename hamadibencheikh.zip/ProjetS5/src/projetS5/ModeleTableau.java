package projetS5;

import java.awt.Color;

import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

public class ModeleTableau extends AbstractTableModel {
	ListeCapteur listeCapteur;
	
	public ModeleTableau(ListeCapteur listeCapteur) {
		this.listeCapteur = listeCapteur;
	}
	
	public int getColumnCount() {
		return 9;
	}
	
	public int getRowCount() {
		return listeCapteur.getNbCapteur();
	}
	
	public Object getValueAt(int indiceLigne, int indiceColonne) {
		Capteur c = listeCapteur.getCapteur(indiceLigne);
		switch(indiceColonne)
		{
		case 0 : return c.numTab;
		case 1 : return c.nom;
		case 2 : return c.bat;
		case 3 : return c.etage;
		case 4 : return c.loc;
		case 5 : return c.type;
		case 6 : return c.valeur;
		case 7 : return c.seuilMin;
		case 8 : return c.seuilMax;
		default: return null;
		}
	}
	
	public String getColumnName(int indiceColonne) {
		switch(indiceColonne)
		{
		case 0 : return "Numero";
		case 1 : return "Nom";
		case 2 : return "Batiment";
		case 3 : return "Etage";
		case 4 : return "Localisation";
		case 5 : return "Type";
		case 6 : return "Valeur";
		case 7 : return "Seuil Min";
		case 8 : return "Seuil Max";
		default: return null;
		}
	}
	
	public void setValueAt(Object val, int indiceLigne, int indiceColonne) {
		Capteur c = listeCapteur.getCapteur(indiceLigne);
		if(indiceColonne==6) {
			c.valeur = (double) ((Integer)val).intValue();
		}
		if(indiceColonne==7) {
			c.seuilMin = (double) ((Integer)val).intValue();
		}
		if(indiceColonne==8) {
			c.seuilMax = (double) ((Integer)val).intValue();
		}
		fireTableDataChanged();
	}
	
	public Class getColumnClass(int indiceColonne) {
		//return getValueAt(0, indiceColonne).getClass();
		return Object.class;
	}
	
	public boolean isCellEditable(int indeLigne, int indiceColonne) {
		return false;
	}
}
