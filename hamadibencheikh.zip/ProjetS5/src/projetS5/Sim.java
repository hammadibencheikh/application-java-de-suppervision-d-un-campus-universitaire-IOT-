package projetS5;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Iterator;

/**
 * Created by med on 11/8/2018.
 */

public class Sim  {

    String dstAddress;
    int dstPort;
    String response = "";
    String msgToSend;



   public Sim (String addr, int port, String msgTo) {
        dstAddress = addr;
        dstPort = port;
        msgToSend = msgTo;

    }


    public String sendData(){
        Socket socket = null;
        DataOutputStream dataOutputStream = null;
        DataInputStream dataInputStream = null;


        try {

            socket = new Socket(dstAddress, dstPort);

            dataOutputStream = new DataOutputStream(socket.getOutputStream());
            dataInputStream = new DataInputStream(socket.getInputStream());


            if(msgToSend != null){
                dataOutputStream.writeUTF(msgToSend);
            }

            response = dataInputStream.readUTF();

            System.out.println(response);


        } catch (UnknownHostException e) {
            e.printStackTrace();
            response = "UnknownHostException: " + e.toString();
        } catch (IOException e) {
            e.printStackTrace();
            response = "IOException: " + e.toString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (dataOutputStream != null) {
                try {
                    dataOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (dataInputStream != null) {
                try {
                    dataInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return response;
    }


    public static void main(String[] args){
        Sim m = new Sim("localhost",6100,"Donnee capteur1 4.2");
        m.sendData();
    }
}