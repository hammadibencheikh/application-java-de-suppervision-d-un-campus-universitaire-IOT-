package projetS5;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

@SuppressWarnings("serial")
public class PanneauDeConnexion extends JFrame implements ActionListener{
	JPanel p=new JPanel(new GridLayout(3,1)) ;
	JPanel p1=new JPanel() ;
	JButton b=new JButton("Connecter") ;
	JLabel l=new JLabel("Port : (Par defaut 61500)") ;
	JTextField t=new JTextField(10) ;
	public PanneauDeConnexion() {
		b.addActionListener(this);
		p.add(l) ;
		p.add(t) ;
		p.add(b) ;
		this.add(p) ;
		this.pack() ;
		
	}
	@Override
	public void actionPerformed(ActionEvent a) {
		if(a.getSource()==b) {
			try {
			
				this.dispose();
				new ServeurClass(Integer.parseInt(t.getText())).run() ;
				
			
			
			}catch (Exception e) {
				JOptionPane.showMessageDialog(null,"Connecté vers le Port par defaut");
				this.dispose();
				new ServeurClass(61500).run() ;
			
				
			}
		}
		
	}
	public static void main(String[] args) {
		new PanneauDeConnexion().setVisible(true) ;
	}
 }
