package projetS5;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import projetS5.Capteur;
import projetS5.ListeCapteur;
import projetS5.ModeleTableau;
//import projetS5.RenduTableau;
import projetS5.Type;

public class Panneau1 extends RecuperationValeurs {
	// panneau de visualisation "temps réel"
	
		public static JPanel panelTableau() {
			JPanel panTab = new JPanel();
			panTab.setLayout(new BorderLayout());
			
			ListeCapteur liste = new ListeCapteur();

			
			int i=0 ;
			try {
				//r�cup�ration des capteurs et valeurs
				Type type=null ;
				java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost/saklibouhlel_walosik_atmaniou?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","") ;    
				java.sql.Statement s=con.createStatement() ;
				ResultSet r=s.executeQuery("select capteur.nomcapteur ,numetage,batiment,type,etat,lieu ,valeur.valeur, max(dateheure), seuilmin, seuilmax from capteur, valeur where valeur.nomcapteur=capteur.nomcapteur and capteur.etat='on' group by nomcapteur ") ;
				while (r.next()) {
					i++ ;
					if(r.getString(4).equals("ELECTRICITE"))
						type=Type.ELECTRICITE ;
					if(r.getString(4).equals("AIR COMPRIMEE"))
						type=Type.AIR_COMPRIMEE ;
					if(r.getString(4).equals("EAU"))
						type=Type.EAU ;
					if(r.getString(4).equals("TEMPERATURE"))
						type=Type.TEMPERATURE ;
					//liste.add
					//TODO RECUPERER SEUIL MIN ET SEUIL MAX???? **************************************
					liste.add(new Capteur(i,r.getString(1),r.getString(3),r.getInt(2),r.getString(6),type,r.getDouble(7), r.getDouble(9), r.getDouble(10)));
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
	
			ModeleTableau modele = new ModeleTableau(liste);
			JTable tableau = new JTable(modele);
			JButton b=new JButton("Refraichir") ;
			b.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					try { 
						
					liste.vider();
						int i=0 ;
						//r�cup�ration des capteurs et valeurs
						Type type=null ;
						   java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost/saklibouhlel_walosik_atmaniou?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","") ;
					        
						java.sql.Statement s=con.createStatement() ;
						ResultSet r=s.executeQuery("select capteur.nomcapteur ,numetage,batiment,type,etat,lieu ,valeur.valeur, max(dateheure), seuilmin, seuilmax from capteur, valeur where valeur.nomcapteur=capteur.nomcapteur and capteur.etat='on' group by nomcapteur ") ;
						while (r.next()) {
							i++ ;
							if(r.getString(4).equals("ELECTRICITE"))
								type=Type.ELECTRICITE ;
							if(r.getString(4).equals("AIR COMPRIMEE"))
								type=Type.AIR_COMPRIMEE ;
							if(r.getString(4).equals("EAU"))
								type=Type.EAU ;
							if(r.getString(4).equals("TEMPERATURE"))
								type=Type.TEMPERATURE ;
							//liste.add
							//TODO RECUPERER SEUIL MIN ET SEUIL MAX???? **************************************
							liste.add(new Capteur(i,r.getString(1),r.getString(3),r.getInt(2),r.getString(6),type,r.getDouble(7), r.getDouble(9), r.getDouble(10)));
						}
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
					modele.fireTableDataChanged() ;
					
				}
				
			});
			tableau.setDefaultRenderer(Object.class, new RenduTableau());
	    		panTab.add(new JScrollPane(tableau),BorderLayout.CENTER);
	    		panTab.add(b,BorderLayout.PAGE_START) ;
	    		return panTab;
		}
}
