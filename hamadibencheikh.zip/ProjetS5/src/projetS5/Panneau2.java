package projetS5;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import com.mysql.jdbc.Statement;

import projetS5.ModeleTableauGestionCapteur;

public class Panneau2 extends RecuperationValeurs {
	
	// panneau de gestion des capteurs
	static String capselect=null ;
	public static JPanel PanelInfoCapteur() {
	
		JPanel panInfoCapteur = new JPanel();
		panInfoCapteur.setPreferredSize(new Dimension(90, 60));
		panInfoCapteur.setLayout(new BorderLayout());
		//TEXTE
		JLabel infoCapteur = new JLabel();
		infoCapteur.setText("Informations capteur");
	
		panInfoCapteur.add(infoCapteur, BorderLayout.PAGE_START);
		
		//NOM CAPTEUR
		JLabel nomCapteur = new JLabel();
		nomCapteur.setText(getNomCapteur());
		//nomCapteur.setBounds(30, 9, 100, 50);
		panInfoCapteur.add(nomCapteur, BorderLayout.CENTER);
		return panInfoCapteur;
	}
	
	public static String getNomCapteur() {
		return capselect;
	}
	
	public static String getTypeCapteur() {
		try {
			 java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost/saklibouhlel_walosik_atmaniou?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","") ;
			java.sql.Statement st=con.createStatement() ;
			ResultSet r=st.executeQuery("select type from capteur where nomcapteur='"+capselect+"'") ;
			while(r.next())
			return (r.getString(1)) ;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
	public static String getLocalizeCapteur() {
		try {
			 java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost/saklibouhlel_walosik_atmaniou?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","") ;
			java.sql.Statement st=con.createStatement() ;
			ResultSet r=st.executeQuery("select lieu from capteur where nomcapteur='"+capselect+"'") ;
			while(r.next())
		return (r.getString(1)) ;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	public static float[] getValeur() {
		float[] ff=new float[100] ;
		int i=0;
		try {
			 java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost/saklibouhlel_walosik_atmaniou?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","") ;
			java.sql.Statement st=con.createStatement() ;
			ResultSet r=st.executeQuery("select valeur from capteur where nomcapteur='"+capselect+"'") ;
			while(r.next()) {
			ff[i]=r.getFloat(1) ;
			return ff ;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ff ;
	}
	
	public static JPanel PanelDroit() { 
		JButton afficher=new JButton("Afficher") ;
		JPanel pt=new JPanel(new GridLayout(2,1)) ;
		JPanel panDroit = new JPanel();
		panDroit.setPreferredSize(new Dimension(240, 500));
		panDroit.setLayout(new BorderLayout());
		
		
		
		
		panDroit.add(afficher, BorderLayout.PAGE_START);
		JLabel typeCapteur = new JLabel(); 
		typeCapteur.setText("Type :");
		
		pt.add(typeCapteur);
		
		JLabel LocalizeCapteur = new JLabel();
		LocalizeCapteur.setText("Lieu : ");
		
		pt.add(LocalizeCapteur);
		panDroit.add(pt,BorderLayout.CENTER) ;
		
		panDroit.add(PanelValeursSeuils(), BorderLayout.PAGE_END);
		afficher.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(capselect==null) {
					JOptionPane.showMessageDialog(null, "Vous devez choisir un capteur");
				}
				else {
				typeCapteur.setText(typeCapteur.getText()+getTypeCapteur());
				LocalizeCapteur.setText(LocalizeCapteur.getText()+getLocalizeCapteur());
				panDroit.add(PanelValeursSeuils(), BorderLayout.PAGE_END);
			}
			}
			
		});
		
		return panDroit;
	}
	
	
	
	public static JPanel PanelValeursSeuils() {
		JLabel l1=new JLabel("Seuil Max :") ; 
		JLabel l2 =new JLabel("Seuil Min :") ;
		JTextField t1=new JTextField(10) ;
		JTextField t2=new JTextField(10) ;
		JButton b1=new JButton("enregistrer") ;
		JPanel p =new JPanel(new GridLayout(3,2)) ;
		p.add(l1) ;
		p.add(t1) ;
		p.add(l2) ;
		p.add(t2) ;
		b1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if((t1.getText()!=null)&&(t2.getText()!=null)) {
					try {
						java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost/saklibouhlel_walosik_atmaniou?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","") ;
						java.sql.Statement st=con.createStatement() ;
						st.executeUpdate("UPDATE capteur set seuilmin="+t2.getText()+" , seuilmax="+t1.getText()+" where nomcapteur='"+capselect+"'") ;
					}catch (SQLException e) {
						e.printStackTrace();
					}
				}
				
			}
			
		}) ;
		p.add(b1) ;
		
		
		JPanel panValeursSeuils = new JPanel();
		try {
			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost/saklibouhlel_walosik_atmaniou?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","") ;
			java.sql.Statement st=con.createStatement() ;
			ResultSet r=st.executeQuery("select type ,seuilmin , seuilmax from capteur where nomcapteur='"+capselect+"'") ;
		panValeursSeuils.setPreferredSize(new Dimension(200, 200));
		panValeursSeuils.setLayout(new BorderLayout());
		//TEXTE
		JLabel valeursSeuils = new JLabel();
		valeursSeuils.setText("Valeurs de ses seuils");
		
		panValeursSeuils.add(valeursSeuils, BorderLayout.PAGE_START);
		panValeursSeuils.add(p,BorderLayout.PAGE_END) ;
		//TODO
		while(r.next()) {
			try {
				System.out.println(t1.getText());
 		ModeleTableauGestionCapteur modele = new ModeleTableauGestionCapteur(r.getString(1),r.getFloat(2),r.getFloat(3));
		JTable tableau = new JTable(modele);
    
    	panValeursSeuils.add(new JScrollPane(tableau));
		
		}catch(NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "entrer le seuil min et le seuil max");
		}
		}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return panValeursSeuils;
	}			
	public static void setcapselect(String s) {
		capselect=s ;
	}
	/*
	public void AddTree(DefaultMutableTreeNode racine, Capteur c) {
		DefaultMutableTreeNode x = new DefaultMutableTreeNode(c);
		racine.add(x);
		return racine;
	}
	*/
	private static String getModel() {
		// TODO Auto-generated method stub
		return null;
	}
/****************/
	public static JPanel PanelGauche(/*ArrayList liste*/) {
		String capselec ;
		JButton b = new JButton ("Refraichir") ;
		ResultSet r ;
		JPanel panGraph = new JPanel();
		panGraph.setPreferredSize(new Dimension(330, 500));
		panGraph.setLayout(new BorderLayout());
		java.sql.Statement s;
		
		try {
			
			s = con.createStatement();
			r=s.executeQuery("select nombatiment from batiment ") ;

		
		
		DefaultMutableTreeNode racine = new DefaultMutableTreeNode("Racine");
		DefaultTreeModel arbre = new DefaultTreeModel(racine);
		
		JTree monArbre3 = new JTree( new DefaultTreeModel(racine)); 
		
		
		// Ajout de fils
		while(r.next()){
			java.sql.Statement s1=con.createStatement() ;
			ResultSet r1 =s1.executeQuery("select numetage from etage where nombatiment='"+r.getString(1)+"'");
			
		    DefaultMutableTreeNode x =   new DefaultMutableTreeNode(r.getString(1));
		    DefaultMutableTreeNode x2 =null ;
		while(r1.next()) {
		
			x2=new DefaultMutableTreeNode("Etage "+ r1.getInt(1));
			x.add(x2);
			ResultSet r2 ;
			java.sql.Statement s2=con.createStatement() ;
			r2=s2.executeQuery("select nomcapteur from capteur where numetage='"+r1.getInt(1)+"' and batiment='"+r.getString(1)+"'") ;
			while(r2.next()) {
				DefaultMutableTreeNode x1 =   new DefaultMutableTreeNode(r2.getString(1));
			x2.add(x1);
			}
		}
		
			racine.add(x);
		    monArbre3.addMouseListener(new MouseAdapter() {
		        public void mouseClicked(MouseEvent me) {
		        	doMouseClicked(me);
		          }
		        void doMouseClicked(MouseEvent me) {
		            TreePath tp = monArbre3.getPathForLocation(me.getX(), me.getY());
		            if (tp != null) {
		            	if(tp.getLastPathComponent().toString().length()>6)
		            	if(tp.getLastPathComponent().toString().substring(0, 7).equals("capteur")) {
		            	setcapselect(tp.getLastPathComponent().toString());
		            	System.out.println(capselect);
		            	}
		            }
		             
		            
		          }
				
		        });
			panGraph.add(monArbre3,BorderLayout.CENTER);
		    
		    panGraph.add(b,BorderLayout.SOUTH) ;
		    b.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					//code pour reexecuter le panneau
				}	
		    	
		    });
		}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return panGraph;
		}
		/*JPanel panGraph = new JPanel();
		panGraph.setPreferredSize(new Dimension(330, 500));
		panGraph.setLayout(new BorderLayout());
		
		DefaultMutableTreeNode racine = new DefaultMutableTreeNode(" ");
		DefaultTreeModel arbreModele = new DefaultTreeModel(racine);
		
		JTree monArbre = new JTree(arbreModele); 
		monArbre.setRootVisible(true);
		
		// Ajout les batiments
		// 
		for( int i = 0; i < nbCapteur; ++i) {
			DefaultMutableTreeNode b = new DefaultMutableTreeNode(c.getBat());
			racine.add(b);
		}	
		
		panGraph.add(monArbre);
		return panGraph;*/
	
	

	
	public static JPanel PanelGlobal2() {
		//ArrayList<Capteur> liste = new ArrayList<>();
		JPanel panGlobal = new JPanel();
		panGlobal.setLayout(new BorderLayout());
		JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,PanelGauche(/*liste*/), PanelDroit());
		splitPane.setDividerLocation(200);
		panGlobal.add(splitPane, BorderLayout.CENTER);
		return panGlobal;
	}
}
