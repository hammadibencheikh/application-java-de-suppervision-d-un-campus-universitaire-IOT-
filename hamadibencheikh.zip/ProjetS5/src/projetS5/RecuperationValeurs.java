package projetS5;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RecuperationValeurs {
	//methode qui retourne une liste des valeurs d'un capteur passe en parametre triee selon la date
	public ArrayList<Float> getValCap(String nomCap){
		ArrayList<Float> list = new ArrayList<>();
		try {
		java.sql.Statement s=con.createStatement() ;
		ResultSet r ;
		r=s.executeQuery("select valeur ,dateheure  from valeur where nomcapteur='"+nomCap+"' order by(dateheure) ASC") ;
		while(r.next()) {
			list.add(r.getFloat(1)) ;
		}
		}catch(SQLException e) {
			
		}
		return list ;
		
	}
	static java.sql.Connection con ;
	//  la base de donnees
		static {
			 try {
			con = DriverManager.getConnection("jdbc:mysql://localhost/saklibouhlel_walosik_atmaniou?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","") ;
				System.out.println("Connexion etablite") ;
			 } catch (SQLException e) {
			
				e.printStackTrace();
			}
		}
}
