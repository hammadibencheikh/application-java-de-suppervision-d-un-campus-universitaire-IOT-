package projetS5;

import java.awt.*;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JSplitPane;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Panneau3 {
	// panneau d'analyse à posteriori
	
	public static XYSeriesCollection createXYDataset() { 
		XYSeries C1 = new XYSeries("Capteur 1");
		C1.add(4, 10); 
		C1.add(5, 20); 
		C1.add(6, 8); 
		C1.add(7, 12);
		XYSeries C2 = new XYSeries("Capteur 2"); 
		C2.add(1, 20);
		C2.add(2, 12);
		C2.add(3, 8);
		C2.add(4, 4);
		XYSeries C3 = new XYSeries("Capteur 3"); 
		C3.add(4, 20);
		C3.add(6, 12);
		C3.add(8, 8);
		C3.add(9, 4);
		XYSeriesCollection dataset = new XYSeriesCollection(); 
		dataset.addSeries(C1);
		dataset.addSeries(C2);
		dataset.addSeries(C3);
		return dataset; 
	}
	
	public static JFreeChart createChart(XYSeriesCollection d) {
		JFreeChart chart = ChartFactory.createXYLineChart("Evolution des Capteurs" , "Temps", "Unit�", d, PlotOrientation.VERTICAL, true, true, false);
		/*****************Recupération des valeurs des JSpinners********************************/
		
		/************Appuie sur le button, marche pas*************/
		
		        XYPlot plot = chart.getXYPlot(); 
				NumberAxis domain = (NumberAxis) plot.getDomainAxis();
				domain.setRange(getValue1(), getValue2());
		      
		/*********************************************************/
		
		// utilisation des value1 et value2 pour l'intervale du tableau axe des abscisses
		/***************************************************************************************/
		return chart;
	}
	
	public static Double getValue1() {
		Double value1= ((Double)spinnerDebut().getValue());
		System.out.println("Value debut ="+value1);
		return value1;
	}
	
	public static Double getValue2() {
		Double value2= ((Double)spinnerFin().getValue());
		System.out.println("Value fin ="+value2);
		return value2;
	}
	
	public static JSpinner spinnerDebut() {
		// Construction des JSpinner
		SpinnerModel value1 =  
			  new SpinnerNumberModel(0.1, //initial value  
					  	0, //minimum value  
		                10, //maximum value - a changer - valeur temps actuelle  
		                0.1); //step  
	    
		JSpinner spinnerDebut = new JSpinner(value1);   
	    spinnerDebut.setBounds(430, 25, 100, 20);
		 
	    return spinnerDebut;
	}
		
	public static JSpinner spinnerFin() {
		SpinnerModel value2 =  
				  new SpinnerNumberModel(10, //initial value  
						  	0, //minimum value  
			                10, //maximum value - a changer - valeur temps actuelle  
			                0.1); //step  
		
		JSpinner spinnerFin = new JSpinner(value2);   
		spinnerFin.setBounds(430, 75, 100, 20);
		
		return spinnerFin;
	}
	
	public static JButton validerButton() {
		JButton valider = new JButton("Valider");
		valider.setBounds(450, 160, 70, 20);
		return valider;
	}

	 
	public static JPanel PanelInfo() {
		JPanel pan = new JPanel();
		pan.setPreferredSize(new Dimension(300, 90));
		pan.setLayout(null);
		
		Object[] type = new Object[] {"EAU", "ELECTRICITE", "AIR_COMPRIMEE", "TEMPERATURE"};
		
		JComboBox<Object> comboBoxType = new JComboBox<>(type);
		comboBoxType.setBounds(100, 10, 170, 50);
		pan.add(comboBoxType);
		
		JComboBox<Object> comboBoxC1 = new JComboBox<>();
		comboBoxC1.setBounds(100, 60, 170, 50);
		pan.add(comboBoxC1);
		
		JComboBox<Object> comboBoxC2 = new JComboBox<>();
		comboBoxC2.setBounds(100, 110, 170, 50);
		pan.add(comboBoxC2);
		
		JComboBox<Object> comboBoxC3 = new JComboBox<>();
		comboBoxC3.setBounds(100, 160, 170, 50);
		pan.add(comboBoxC3);
		
		JButton valider = validerButton();
		pan.add(valider);/*
		valider.addActionListener(new ActionListener(){
		      public void actionPerformed(ActionEvent ae){
		        System.out.println("Going up");
		      }});*/
		
		JSpinner spinnerDebut = spinnerDebut();
		JSpinner spinnerFin = spinnerFin();
		
		//Ajout des spinners au panel
		pan.add(spinnerDebut);
		pan.add(spinnerFin);
					
				// Le temps fin ne peut pas etre inferieur a celui du début /!\
				
				JLabel seconde1 = new JLabel();
				seconde1.setText("seconde(s)");
				seconde1.setBounds(550, 10, 100, 50);
				pan.add(seconde1);
				
				JLabel seconde2 = new JLabel();
				seconde2.setText("seconde(s)");
				seconde2.setBounds(550, 60, 100, 50);
				pan.add(seconde2);
				
				JLabel typeLegend = new JLabel();
				typeLegend.setText("Type");
				typeLegend.setBounds(30, 10, 100, 50);
				pan.add(typeLegend);
			
				JLabel C1Legend = new JLabel();
				C1Legend.setText("C1");
				C1Legend.setBounds(30, 60, 100, 50);
				pan.add(C1Legend);
				
				JLabel C2Legend = new JLabel();
				C2Legend.setText("C2");
				C2Legend.setBounds(30, 110, 100, 50);
				pan.add(C2Legend);
				
				JLabel C3Legend = new JLabel();
				C3Legend.setText("C3");
				C3Legend.setBounds(30, 160, 100, 50);
				pan.add(C3Legend);
				
				JLabel debutLegend = new JLabel();
				debutLegend.setText("D�but");
				debutLegend.setBounds(360, 10, 100, 50);
				pan.add(debutLegend);
				
				JLabel finLegend = new JLabel();
				finLegend.setText("Fin");
				finLegend.setBounds(360, 60, 100, 50);
				pan.add(finLegend);
		
		return pan;
	}
	
	public static JPanel PanelGraph() {
		JPanel panGraph = new JPanel();
		
		panGraph.setLayout(new BorderLayout());
		
		
		JFreeChart graph = createChart(createXYDataset());
		ChartPanel cp = new ChartPanel(graph,true);
		panGraph.add(cp);
		
		return panGraph;
	}
	
	public static JPanel PanelGlobal() {
		JPanel panGlobal = new JPanel();
		
		panGlobal.setLayout(new BorderLayout());
		//panGlobal.add(PanelInfo(), BorderLayout.PAGE_END);
		//panGlobal.add(PanelGraph(), BorderLayout.LINE_START);
		
		 
		JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,PanelInfo(),PanelGraph());
		splitPane.setDividerLocation(220);
		panGlobal.add(splitPane, BorderLayout.CENTER);
		
		return panGlobal;
	}
}
