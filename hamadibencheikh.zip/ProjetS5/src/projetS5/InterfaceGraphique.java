package projetS5;

import javax.swing.JFrame;
import javax.swing.JSplitPane;

public class InterfaceGraphique {
	public static void main(String[] args) { 
		
		JFrame fenetrePrincipale = new JFrame();
		
		fenetrePrincipale.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fenetrePrincipale.setSize(1280,900);
		fenetrePrincipale.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		//fenetrePrincipale.setResizable(false);
		//int x1=fenetrePrincipale.getWidth();
	    //int y1=fenetrePrincipale.getHeight();
		//fenetrePrincipale.add(PanelGlobal(), BorderLayout.LINE_END);
		//fenetrePrincipale.add(PanelTableau(), BorderLayout.PAGE_END);
		//fenetrePrincipale.add(PanelGlobal2(), BorderLayout.LINE_START);
		
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,Panneau2.PanelGlobal2(),Panneau3.PanelGlobal());
		splitPane.setDividerLocation(570);
		
		JSplitPane splitPane2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,splitPane, Panneau1.panelTableau());
		splitPane2.setDividerLocation(550);
		fenetrePrincipale.add(splitPane2);
		
		fenetrePrincipale.setVisible(true);
	}	
}
